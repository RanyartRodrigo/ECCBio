This package provides a stack system for category code tables in LuaTeX.
The code here builds on the LaTeX kernel support for LuaTeX (LaTeX2e 
2015/10/01 onward), which is also available as `ltluatex.tex` for plain
TeX users and those with older LaTeX kernel implementations.
