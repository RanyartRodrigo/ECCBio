The LaTeX kernel (LaTeX2e 2015/10/01 onward) builds in support for 
LuaTeX functionality, also available as `ltluatex.tex` for users for 
users of plain TeX and those with older LaTeX kernel implementations.
This support is based on ideas taken from the original `luatexbase`
package, but there are interface differences. This 'stub' package
provides a compatibility layer to allow existing packages to upgrade
smoothly to the new support structure.
